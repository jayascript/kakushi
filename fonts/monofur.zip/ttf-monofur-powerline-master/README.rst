=====================
ttf-monofur-powerline
=====================

-------------------------------------------------
Patched version of Monofur with Powerline symbols
-------------------------------------------------

:Maintainer: Riccardo Sven Risuleo <riccardosven [at] gmail [dot] com>
:Author: Tobias Benjamin Köhler
:Patch by: Julio Biason <julio [dot] biason [at] gmail [dot] com>
:Version: 1.0-git
:License: BY-NC-SA_
:Source: https://github.com/rsrsl/ttf-monofur-powerline

Merits
======
All the merits go to Tobias, for the original Monofur_ font, and to
Julio_, who applied the patch to include the powerline symbols

.. _BY-NC-SA: http://creativecommons.org/licenses/by-nc-sa/3.0/
.. _Monofur: http://www.dafont.com/monofur.font
.. _Julio: https://github.com/jbiason
